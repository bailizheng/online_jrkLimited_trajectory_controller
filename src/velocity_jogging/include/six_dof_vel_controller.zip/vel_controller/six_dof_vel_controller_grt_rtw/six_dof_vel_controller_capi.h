/*
 * six_dof_vel_controller_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "six_dof_vel_controller".
 *
 * Model version              : 1.14
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C++ source code generated on : Fri May 17 15:21:32 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_six_dof_vel_controller_capi_h
#define RTW_HEADER_six_dof_vel_controller_capi_h
#include "six_dof_vel_controller.h"

extern void six_dof_vel_controller_InitializeDataMapInfo(void);

#endif                                 /* RTW_HEADER_six_dof_vel_controller_capi_h */

/* EOF: six_dof_vel_controller_capi.h */
